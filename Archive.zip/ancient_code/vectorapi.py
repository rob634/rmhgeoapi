"""
PostGIS Repository - Database operations for vector data
Handles all PostGIS interactions without business logic
"""
import json
import logging
from typing import Dict, List, Optional, Tuple
import psycopg
from psycopg import sql
from psycopg.rows import dict_row
from geopandas import GeoDataFrame
from shapely import wkb, wkt
from logger_setup import logger


class PostGISRepository:
    """Repository for PostGIS database operations"""
    
    def __init__(self, connection_string: str = None):
        """
        Initialize PostGIS repository with connection
        
        Args:
            connection_string: PostgreSQL connection string
                             If None, uses hardcoded credentials
        """
        if connection_string:
            self.connection_string = connection_string
        else:
            # Hardcoded for MVP - replace with Config.get_postgis_connection_string() later
            self.connection_string = (
                "postgresql://geouser:GeoPass123!@your-postgis-host.postgres.database.azure.com:5432/geodb"
            )
        
        logger.info("PostGISRepository initialized with psycopg3")
    
    def _get_connection(self):
        """Get database connection using psycopg3"""
        try:
            conn = psycopg.connect(self.connection_string)
            return conn
        except Exception as e:
            logger.error(f"Failed to connect to PostGIS: {str(e)}")
            raise
    
    def table_exists(self, schema: str, table_name: str) -> bool:
        """
        Check if table exists in database
        
        Args:
            schema: Database schema name
            table_name: Table name to check
            
        Returns:
            bool: True if table exists
        """
        query = """
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = %s 
                AND table_name = %s
            );
        """
        
        try:
            with self._get_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(query, (schema, table_name))
                    result = cur.fetchone()[0]
                    logger.debug(f"Table {schema}.{table_name} exists: {result}")
                    return result
        except Exception as e:
            logger.error(f"Error checking table existence: {str(e)}")
            raise
    
    def drop_table(self, schema: str, table_name: str, cascade: bool = False) -> bool:
        """
        Drop table from database
        
        Args:
            schema: Database schema
            table_name: Table to drop
            cascade: Drop dependent objects
            
        Returns:
            bool: True if successful
        """
        try:
            with self._get_connection() as conn:
                with conn.cursor() as cur:
                    drop_clause = "CASCADE" if cascade else ""
                    query = sql.SQL("DROP TABLE IF EXISTS {}.{} {}").format(
                        sql.Identifier(schema),
                        sql.Identifier(table_name),
                        sql.SQL(drop_clause)
                    )
                    cur.execute(query)
                    conn.commit()
                    logger.info(f"Dropped table {schema}.{table_name}")
                    return True
        except Exception as e:
            logger.error(f"Error dropping table: {str(e)}")
            raise
    
    def create_table_from_gdf(self, gdf: GeoDataFrame, schema: str, 
                            table_name: str, geometry_col: str = 'shape') -> bool:
        """
        Create PostGIS table from GeoDataFrame
        
        Args:
            gdf: GeoDataFrame to upload
            schema: Target schema
            table_name: Target table name
            geometry_col: Name for geometry column (default 'shape' for ArcGIS)
            
        Returns:
            bool: True if successful
        """
        try:
            # Get geometry type and SRID
            geom_type = gdf.geometry.iloc[0].geom_type.upper()
            srid = 4326  # Always WGS84 as per requirements
            
            with self._get_connection() as conn:
                with conn.cursor() as cur:
                    # Create schema if not exists
                    cur.execute(sql.SQL("CREATE SCHEMA IF NOT EXISTS {}").format(
                        sql.Identifier(schema)
                    ))
                    
                    # Build CREATE TABLE statement
                    columns = []
                    
                    # Add objectid as serial primary key for ArcGIS
                    columns.append("objectid SERIAL PRIMARY KEY")
                    
                    # Add data columns
                    for col in gdf.columns:
                        if col == gdf.geometry.name:
                            continue  # Skip geometry column, add it separately
                        
                        # Map pandas dtype to PostgreSQL type
                        dtype = str(gdf[col].dtype)
                        if 'int' in dtype:
                            pg_type = 'INTEGER'
                        elif 'float' in dtype:
                            pg_type = 'DOUBLE PRECISION'
                        elif 'bool' in dtype:
                            pg_type = 'BOOLEAN'
                        elif 'datetime' in dtype:
                            pg_type = 'TIMESTAMP'
                        else:
                            pg_type = 'TEXT'
                        
                        # Clean column name for PostgreSQL
                        clean_col = self._clean_column_name(col)
                        columns.append(f'"{clean_col}" {pg_type}')
                    
                    # Create table
                    create_sql = sql.SQL("""
                        CREATE TABLE {}.{} (
                            {}
                        )
                    """).format(
                        sql.Identifier(schema),
                        sql.Identifier(table_name),
                        sql.SQL(', '.join(columns))
                    )
                    
                    cur.execute(create_sql)
                    
                    # Add geometry column using PostGIS function
                    cur.execute("""
                        SELECT AddGeometryColumn(%s, %s, %s, %s, %s, 2)
                    """, (schema, table_name, geometry_col, srid, geom_type))
                    
                    conn.commit()
                    logger.info(f"Created table {schema}.{table_name} with {geom_type} geometry")
                    
                    # Now insert the data
                    return self.insert_gdf_batch(gdf, schema, table_name, geometry_col)
                    
        except Exception as e:
            logger.error(f"Error creating table from GeoDataFrame: {str(e)}")
            raise
    
    def insert_gdf_batch(self, gdf: GeoDataFrame, schema: str, 
                        table_name: str, geometry_col: str = 'shape',
                        batch_size: int = 5000) -> bool:
        """
        Insert GeoDataFrame in batches using psycopg3
        
        Args:
            gdf: GeoDataFrame to insert
            schema: Target schema
            table_name: Target table
            geometry_col: Geometry column name
            batch_size: Records per batch
            
        Returns:
            bool: True if successful
        """
        try:
            # Prepare data for insertion
            gdf = gdf.copy()
            
            # Convert geometry to WKT for insertion
            gdf['geom_wkt'] = gdf.geometry.apply(lambda x: x.wkt if x else None)
            
            # Get non-geometry columns
            data_columns = [self._clean_column_name(col) for col in gdf.columns 
                          if col not in [gdf.geometry.name, 'geom_wkt']]
            
            with self._get_connection() as conn:
                with conn.cursor() as cur:
                    # Build INSERT statement with psycopg3 style
                    placeholders = ', '.join(['%s'] * len(data_columns))
                    column_list = ', '.join([f'"{col}"' for col in data_columns])
                    
                    insert_query = f"""
                        INSERT INTO {schema}.{table_name} ({column_list}, {geometry_col})
                        VALUES ({placeholders}, ST_GeomFromText(%s, 4326))
                    """
                    
                    # Batch insert
                    total_rows = len(gdf)
                    for i in range(0, total_rows, batch_size):
                        batch = gdf.iloc[i:i+batch_size]
                        
                        # Prepare batch data
                        batch_data = []
                        for _, row in batch.iterrows():
                            row_data = []
                            for col in gdf.columns:
                                if col not in [gdf.geometry.name, 'geom_wkt']:
                                    val = row[col]
                                    # Handle NaN/None values
                                    if pd.isna(val):
                                        row_data.append(None)
                                    else:
                                        row_data.append(val)
                            row_data.append(row['geom_wkt'])
                            batch_data.append(tuple(row_data))
                        
                        # Execute batch with psycopg3's executemany
                        cur.executemany(insert_query, batch_data)
                        
                        logger.info(f"Inserted batch {i//batch_size + 1} "
                                  f"({min(i+batch_size, total_rows)}/{total_rows} rows)")
                    
                    conn.commit()
                    
                    # Create spatial index
                    self._create_spatial_index(cur, schema, table_name, geometry_col)
                    conn.commit()
                    
                    logger.info(f"Successfully inserted {total_rows} rows into {schema}.{table_name}")
                    return True
                    
        except Exception as e:
            logger.error(f"Error inserting GeoDataFrame batch: {str(e)}")
            raise
    
    def add_objectid_sequence(self, schema: str, table_name: str) -> bool:
        """
        Add auto-incrementing objectid for ArcGIS compatibility
        
        Args:
            schema: Database schema
            table_name: Table name
            
        Returns:
            bool: True if successful
        """
        try:
            with self._get_connection() as conn:
                with conn.cursor() as cur:
                    # Update null objectids with sequence values
                    cur.execute(f"""
                        UPDATE {schema}.{table_name}
                        SET objectid = nextval(pg_get_serial_sequence('{schema}.{table_name}', 'objectid'))
                        WHERE objectid IS NULL
                    """)
                    conn.commit()
                    return True
        except Exception as e:
            logger.error(f"Error adding objectid sequence: {str(e)}")
            raise
    
    def _clean_column_name(self, col_name: str) -> str:
        """
        Clean column name for PostgreSQL/ArcGIS compatibility
        
        Args:
            col_name: Original column name
            
        Returns:
            str: Cleaned column name
        """
        import re
        
        # Replace non-alphanumeric with underscore
        clean = re.sub(r'[^a-zA-Z0-9_]', '_', col_name)
        
        # Ensure doesn't start with number
        if clean and clean[0].isdigit():
            clean = f"f_{clean}"
        
        # Truncate to 63 characters (PostgreSQL limit)
        clean = clean[:63]
        
        # Lowercase for PostgreSQL
        return clean.lower()
    
    def _create_spatial_index(self, cursor, schema: str, table_name: str, 
                             geometry_col: str) -> None:
        """Create spatial index on geometry column"""
        try:
            index_name = f"{table_name}_{geometry_col}_idx"
            cursor.execute(f"""
                CREATE INDEX IF NOT EXISTS {index_name} 
                ON {schema}.{table_name} 
                USING GIST ({geometry_col})
            """)
            logger.info(f"Created spatial index {index_name}")
        except Exception as e:
            logger.warning(f"Could not create spatial index: {str(e)}")