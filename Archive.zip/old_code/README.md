# Redesign Architecture - August 29, 2025

This folder contains the complete architectural redesign based on the specifications in `redesign.md` and the JSON infrastructure design document.

## **Core Design Pattern: Job → Stage → Task**

```
HTTP Request → Job → Stage 1 → Tasks (parallel) → Stage 2 → Tasks (parallel) → Completion
                ↓       ↓                        ↓                            ↓
            Job Record  Stage Tasks         Next Stage Tasks           Final Results
```

## **Abstract Base Classes**

### **BaseController** (`base_controller.py`)
- Abstract controller defining job type, stages, and orchestration
- Generates idempotent job IDs from parameter hashing
- Validates stage definitions and dependencies
- Handles job record creation and queue message generation

### **BaseStage** (`base_stage.py`)
- Abstract stage execution logic for sequential operations
- Creates tasks for parallel execution within the stage
- Handles stage prerequisites and completion detection
- Aggregates results from all tasks in the stage

### **BaseTask** (`base_task.py`)
- Abstract task execution for parallelizable operations
- Handles individual task processing with retry logic
- Manages heartbeat updates and failure handling
- Extracts metrics for monitoring

### **BaseJob** (`base_job.py`)
- Abstract job state management and completion detection
- Handles stage transitions and result aggregation
- Implements "last task turns out the lights" pattern
- Manages job lifecycle from queued to completed

## **Key Features**

### **Sequential Stages with Parallel Tasks**
- Stages execute sequentially (Stage 1 → Stage 2 → ...)
- Tasks within each stage execute in parallel
- Results from previous stages are passed to next stages

### **"Last Task Turns Out the Lights"**
- The final task in each stage handles stage completion
- Atomic SQL operations prevent race conditions
- Stage completion triggers next stage or job completion

### **Idempotent Job IDs**
- Job IDs generated from SHA256 hash of parameters
- Duplicate submissions return existing job
- Natural deduplication without additional logic

### **Atomic Completion Detection**
- PostgreSQL atomic operations for task completion
- No race conditions between parallel tasks
- Consistent state management

## **Next Steps**

1. **Create HelloWorldController** - First concrete implementation
2. **Integrate with existing queue infrastructure** 
3. **Test Hello World → Worlds Reply pattern**
4. **Add deprecation warnings to existing controllers**
5. **Migrate other operations to new pattern**

## **Dependencies**

This redesign leverages the existing JSON infrastructure:
- **PostgreSQL**: For atomic job/task state management
- **Azure Functions**: For queue-driven processing
- **Storage Queues**: For job and task message handling
- **Application Insights**: For monitoring and metrics

## **Status**

✅ **Phase 1 Complete**: Abstract base classes implemented  
⏳ **Phase 2 Next**: HelloWorldController implementation  
⏳ **Phase 3 Pending**: Queue integration  
⏳ **Phase 4 Pending**: Completion detection  
⏳ **Phase 5 Pending**: Testing & validation  

See `HELLO_WORLD_IMPLEMENTATION_PLAN.md` for detailed implementation roadmap.