"""
Factory for creating job controllers.

This module provides a factory pattern for instantiating the appropriate
controller based on operation type, similar to ServiceFactory but for
the controller layer.

Author: Azure Geospatial ETL Team
Version: 1.0.0
"""
from typing import Optional

from base_controller import BaseJobController
from controller_exceptions import ControllerNotFoundError
from logger_setup import get_logger

logger = get_logger(__name__)


class ControllerFactory:
    """
    Factory class for creating appropriate controller instances.
    
    Maps operation types to controller classes and handles instantiation.
    This enables adding new controllers without modifying routing logic.
    
    The factory pattern provides several benefits:
        1. Decouples controller creation from usage
        2. Centralizes operation routing decisions
        3. Enables easy addition of new controllers
        4. Supports gradual migration from services to controllers
    
    Current Implementation Status:
        Phase 1 (COMPLETE):
            - hello_world → HelloWorldController ✅
            - hello_world_sequential → HelloWorldSequentialController ✅ (Job Chaining Test)
            - test → HelloWorldController ✅
            
        Phase 2 (COMPLETE):
            - list_container → ContainerController ✅ DEPLOYED
            - sync_container → ContainerController ✅ DEPLOYED
            - catalog_file → STACController ✅ DEPLOYED
            
        Phase 3 (IN PROGRESS):
            - generate_tiling_plan → TilingController ✅ IMPLEMENTED
            - tile_raster → TilingController ✅ IMPLEMENTED
            - cog_conversion → RasterController (TODO)
            - validate_raster → RasterController (TODO)
            - process_tiled_raster → TiledRasterController (TODO)
    
    Usage:
        >>> controller = ControllerFactory.get_controller('hello_world')
        >>> job_id = controller.process_job(request)
    """
    
    # Class-level cache for controller instances (singleton pattern)
    _controller_cache = {}
    
    @staticmethod
    def get_controller(operation_type: str) -> BaseJobController:
        """
        Get the appropriate controller for the operation type.
        
        Uses a singleton pattern with caching to avoid recreating controllers
        for repeated requests. Controllers are stateless and thread-safe.
        
        Args:
            operation_type: Type of operation to perform (e.g., 'hello_world', 
                          'list_container', 'cog_conversion')
            
        Returns:
            BaseJobController: Instantiated controller ready to process jobs
            
        Raises:
            ControllerNotFoundError: If no controller exists for the operation.
                                   The error includes the operation type and
                                   suggests falling back to direct service.
        
        Example:
            >>> try:
            ...     controller = ControllerFactory.get_controller('hello_world')
            ...     job_id = controller.process_job(request)
            ... except ControllerNotFoundError:
            ...     # Fall back to direct service call
            ...     service = ServiceFactory.get_service('hello_world')
            ...     result = service.process(request)
        """
        logger.info(f"🔍 DEBUG: Getting controller for operation: {operation_type}")
        logger.info(f"DEBUG: Available cached controllers: {list(ControllerFactory._controller_cache.keys())}")
        
        # Check cache first for efficiency
        if operation_type in ControllerFactory._controller_cache:
            logger.debug(f"Returning cached controller for {operation_type}")
            return ControllerFactory._controller_cache[operation_type]
        
        controller = None
        logger.info(f"DEBUG: No cached controller for {operation_type}, creating new one...")
        
        # Hello World operations (Phase 1 - COMPLETE)
        if operation_type in ['hello_world', 'test']:
            from hello_world_controller import HelloWorldController
            controller = HelloWorldController()
        
        # Sequential Hello World operations (Job Chaining Test)
        elif operation_type == 'hello_world_sequential':
            logger.info(f"DEBUG: Matched hello_world_sequential operation type")
            from hello_world_sequential_controller import HelloWorldSequentialController
            controller = HelloWorldSequentialController()
            logger.info(f"DEBUG: Created HelloWorldSequentialController instance: {controller}")
            logger.info(f"Using HelloWorldSequentialController for {operation_type}")
        
        # Container operations (Phase 2 - IMPLEMENTED)
        elif operation_type in ['list_container', 'sync_container']:
            from container_controller import ContainerController
            controller = ContainerController()
            logger.info(f"Using ContainerController for {operation_type}")
        
        # STAC operations
        elif operation_type == 'catalog_file':
            from stac_controller import STACController
            controller = STACController()
            logger.info(f"Using STACController for {operation_type}")
        
        # Tiling operations (Phase 3 - PostGIS-based tiling)
        elif operation_type in ['generate_tiling_plan', 'tile_raster']:
            from tiling_controller import TilingController
            controller = TilingController()
            logger.info(f"Using TilingController for {operation_type}")
        
        # Database metadata operations
        elif operation_type in ['list_collections', 'list_items', 'get_database_summary', 
                                'get_collection_details', 'export_metadata', 'query_spatial',
                                'get_statistics']:
            from database_metadata_controller import DatabaseMetadataController
            controller = DatabaseMetadataController()
            logger.info(f"Using DatabaseMetadataController for {operation_type}")
        
        # Other STAC operations (to be added later)
        elif operation_type in ['stac_item_quick', 'stac_item_full', 'stac_item_smart']:
            # These will be added after catalog_file is proven
            logger.warning(f"Controller not yet implemented for {operation_type}, falling back to direct service")
            raise ControllerNotFoundError(operation_type)
        
        # Raster operations (to be added in Phase 2)
        elif operation_type in ['cog_conversion', 'validate_raster', 'process_raster']:
            # Phase 2: Will wrap RasterProcessorService
            logger.warning(f"Controller not yet implemented for {operation_type}, falling back to direct service")
            raise ControllerNotFoundError(operation_type)
        
        # Tiled raster operations (to be added in Phase 2)
        elif operation_type in ['process_tiled_raster', 'prepare_tiled_cog', 'create_tiled_cog']:
            # Phase 2: Will fix TiledRasterProcessor issues
            logger.warning(f"Controller not yet implemented for {operation_type}, falling back to direct service")
            raise ControllerNotFoundError(operation_type)
        
        # Cache the controller if one was created
        if controller:
            ControllerFactory._controller_cache[operation_type] = controller
            logger.info(f"DEBUG: Successfully cached new controller for {operation_type}")
            logger.info(f"DEBUG: Controller type: {type(controller).__name__}")
            return controller
        
        # Default: No controller found
        else:
            logger.error(f"❌ No controller found for operation type: {operation_type}")
            logger.error(f"DEBUG: Checked conditions but no controller matched")
            logger.error(f"DEBUG: operation_type value: '{operation_type}' (type: {type(operation_type)})")
            logger.error(f"DEBUG: operation_type == 'hello_world_sequential': {operation_type == 'hello_world_sequential'}")
            raise ControllerNotFoundError(operation_type)
    
    @staticmethod
    def has_controller(operation_type: str) -> bool:
        """
        Check if a controller exists for the operation type.
        
        Args:
            operation_type: Operation to check
            
        Returns:
            bool: True if controller exists
        """
        try:
            ControllerFactory.get_controller(operation_type)
            return True
        except ControllerNotFoundError:
            return False
    
    @staticmethod
    def list_available_controllers() -> list:
        """
        List all available controller operation types.
        
        Returns:
            list: Operation types with implemented controllers
            
        Example:
            >>> available = ControllerFactory.list_available_controllers()
            >>> print(f"Available controllers: {', '.join(available)}")
            Available controllers: hello_world, test
        """
        # Phase 1 - COMPLETE
        # Phase 2 - COMPLETE  
        # Phase 3 - IN PROGRESS (Tiling)
        implemented = [
            'hello_world',
            'hello_world_sequential',
            'test',
            'list_container',
            'sync_container',
            'catalog_file',
            'generate_tiling_plan',
            'tile_raster',
            'list_collections',
            'list_items',
            'get_database_summary',
            'get_collection_details',
            'export_metadata',
            'query_spatial',
            'get_statistics'
        ]
        
        # Phase 2 - IN PROGRESS (will be added as implemented)
        # upcoming = [
        #     'list_container',
        #     'sync_container', 
        #     'catalog_file',
        #     'stac_item_quick', 
        #     'stac_item_full', 
        #     'stac_item_smart'
        # ]
        
        # Phase 3 - PLANNED
        # planned = [
        #     'cog_conversion',
        #     'validate_raster',
        #     'process_raster',
        #     'process_tiled_raster',
        #     'prepare_tiled_cog',
        #     'create_tiled_cog'
        # ]
        
        return implemented
    
    @staticmethod
    def clear_cache() -> None:
        """
        Clear the controller cache.
        
        Useful for testing or when controllers need to be reinitialized.
        Controllers are stateless, so this is generally safe to call.
        
        Example:
            >>> ControllerFactory.clear_cache()
            >>> # Next get_controller() call will create fresh instance
        """
        ControllerFactory._controller_cache.clear()
        logger.info("Controller cache cleared")