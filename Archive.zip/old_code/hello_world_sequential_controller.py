"""
HelloWorldSequential controller for testing the Job Chaining architecture.

This controller implements a comprehensive 3-stage sequential job workflow to validate
the job chaining framework. It proves that jobs can orchestrate multi-stage processes
while maintaining task parallelism within each stage.

Stages:
    1. Initial Hello (n parallel tasks)
    2. Validation (1 task validates Stage 1 completion)
    3. Response (n parallel tasks respond to Stage 1 tasks)

The test proves inter-stage data flow by having Stage 3 tasks reference
specific task IDs from Stage 1, with the exact message format:
"Task {current_task_id} saying hello to {stage1_task_id}"

Author: Azure Geospatial ETL Team
Version: 1.0.0
Date: August 28, 2025
"""
import json
import time
from datetime import datetime, timezone
from typing import List, Dict, Any

from base_controller import BaseJobController
from task_manager import TaskManager
from controller_exceptions import InvalidRequestError, TaskCreationError
from logger_setup import get_logger
from schema_enforcement import SchemaDefinition

logger = get_logger(__name__)


class HelloWorldSequentialController(BaseJobController):
    """
    Sequential job controller demonstrating 3-stage job chaining architecture.
    
    This controller proves that the job chaining framework can handle complex
    multi-stage workflows with inter-stage data dependencies.
    
    Architecture Pattern:
        1 hello_world_sequential job → 3 sequential stages
        Stage 1: n parallel hello_world_stage1 tasks
        Stage 2: 1 hello_world_stage2_validation task  
        Stage 3: n parallel hello_world_stage3_response tasks
    
    Key Validation Points:
        - Stage progression with proper job state management
        - Inter-stage data flow (Stage 1 task IDs → Stage 3 responses)
        - Task count consistency (n tasks in Stage 1 = n tasks in Stage 3)
        - Job completion only after ALL 3 stages finish
        - Comprehensive result aggregation with actual timing metrics
    
    Request Parameters:
        - dataset_id (required): Dataset identifier
        - resource_id (required): Resource identifier  
        - version_id (optional): Version identifier
        - n (optional): Number of hello tasks to create (1-20, default: 1)
        - message (optional): Base message for hello tasks
        
    Example Usage:
        POST /api/jobs/hello_world_sequential
        {
            "job_type": "hello_world_sequential",
            "dataset_id": "sequential_test",
            "resource_id": "3_stage_hello", 
            "version_id": "v1",
            "n": 3,
            "message": "Sequential Test"
        }
    """
    
    def __init__(self):
        """Initialize controller with task manager."""
        super().__init__()
        self.task_manager = TaskManager()
    
    def extend_schema(self, base_schema: SchemaDefinition) -> SchemaDefinition:
        """
        Extend base schema with HelloWorldSequential-specific parameters.
        
        Args:
            base_schema: Base job request schema
            
        Returns:
            SchemaDefinition: Schema with sequential hello world parameters
        """
        return base_schema \
            .optional("n", int, "Number of hello world tasks to create (1-20)") \
            .optional("message", str, "Base message for sequential hello world tasks")
    
    def validate_request(self, request: Dict[str, Any]) -> bool:
        """
        Validate sequential hello world request using strict schema enforcement.
        
        Args:
            request: Request dictionary
            
        Returns:
            bool: True if valid
            
        Raises:
            SchemaValidationError: Detailed schema violation information
        """
        # Call parent validation (includes schema enforcement)
        is_valid = super().validate_request(request)
        
        # Additional HelloWorldSequential-specific validation beyond schema
        n = request.get('n', 1)
        if n is not None:
            # Convert string to int if needed (schema allows this)
            if isinstance(n, str):
                try:
                    n = int(n)
                    request['n'] = n  # Update request
                except (ValueError, TypeError):
                    from schema_enforcement import SchemaValidationError, SchemaViolation, SchemaViolationType
                    violation = SchemaViolation(
                        type=SchemaViolationType.INVALID_TYPE,
                        parameter="n",
                        expected="integer or string-integer",
                        actual=f"string: {n}",
                        message=f"Cannot convert 'n' parameter '{n}' to integer"
                    )
                    raise SchemaValidationError([violation], "HelloWorldSequentialController.validate_request")
            
            # Range validation for sequential test (limited to 20 for safety)
            if n < 1 or n > 20:
                from schema_enforcement import SchemaValidationError, SchemaViolation, SchemaViolationType
                violation = SchemaViolation(
                    type=SchemaViolationType.INVALID_VALUE,
                    parameter="n",
                    expected="integer between 1 and 20",
                    actual=str(n),
                    message=f"'n' parameter must be between 1 and 20 for sequential test, got {n}"
                )
                raise SchemaValidationError([violation], "HelloWorldSequentialController.validate_request")
        
        self.logger.info(f"✅ HelloWorldSequential request validated - will create 3-stage job with {n} tasks in Stage 1 and Stage 3")
        return is_valid
    
    def create_tasks(self, job_id: str, request: Dict[str, Any]) -> List[str]:
        """
        Create Stage 1 tasks and initialize sequential job configuration.
        
        This method:
        1. Initializes the job with 3-stage sequential configuration
        2. Creates n Stage 1 hello world tasks
        3. Sets up stage tracking for job chaining framework
        
        Args:
            job_id: Parent job ID
            request: Validated request containing 'n' parameter
            
        Returns:
            List[str]: List of Stage 1 task IDs (length = n)
            
        Raises:
            TaskCreationError: If any task creation fails
        """
        n = request.get('n', 1)  # Number of hello world tasks to create in Stage 1
        base_message = request.get('message', 'Sequential Hello Test')
        
        self.logger.info(f"🚀 Creating HelloWorldSequential job {job_id} with {n} Stage 1 tasks")
        self.logger.info(f"DEBUG: Job creation parameters - dataset_id={request.get('dataset_id')}, resource_id={request.get('resource_id')}, n={n}, message={base_message}")
        
        # Initialize job with 3-stage configuration
        self._initialize_sequential_job(job_id, request)
        
        # Stage 1: Create initial hello tasks
        task_ids = []
        failed_tasks = []
        
        for i in range(n):
            # Create task data for each Stage 1 hello world task
            task_data = {
                'dataset_id': request.get('dataset_id'),
                'resource_id': request.get('resource_id'),
                'version_id': request.get('version_id', 'v1'),
                'job_id': job_id,
                'stage': 1,
                'hello_number': i + 1,
                'message': f"{base_message} - Initial Hello {i + 1}",
                'expected_total': n,
                'parent_job_id': job_id
            }
            
            # Create task with unique index
            task_id = self.task_manager.create_task(
                job_id=job_id,
                task_type='hello_world_stage1',
                task_data=task_data,
                index=i
            )
            
            if task_id:
                # Queue the task for processing
                self.logger.info(f"DEBUG: About to queue Stage 1 task {i+1}/{n} with task_data: {task_data}")
                if self.queue_task(task_id, task_data):
                    task_ids.append(task_id)
                    self.logger.info(f"✅ Created and queued Stage 1 task {i+1}/{n}: {task_id[:16]}...")
                else:
                    failed_tasks.append(i + 1)
                    self.logger.error(f"❌ Failed to queue Stage 1 task {i+1}/{n}: {task_id[:16]}...")
            else:
                failed_tasks.append(i + 1)
                self.logger.error(f"❌ Failed to create Stage 1 task {i+1}/{n}")
        
        # Check if we created the expected number of tasks
        if len(task_ids) == 0:
            raise TaskCreationError("Failed to create any Stage 1 hello_world tasks", job_id=job_id)
        elif len(task_ids) != n:
            self.logger.warning(f"Created {len(task_ids)}/{n} Stage 1 tasks (some failed)")
            if failed_tasks:
                self.logger.warning(f"Failed Stage 1 tasks: {failed_tasks}")
            # Continue with partial success - at least some tasks were created
        
        self.logger.info(f"✅ Successfully created {len(task_ids)}/{n} Stage 1 tasks for sequential job {job_id}")
        return task_ids
    
    def _initialize_sequential_job(self, job_id: str, request: Dict[str, Any]):
        """
        Initialize job with sequential stage configuration.
        
        Sets up the job table record with the 6 mandatory stage tracking fields
        required by the job chaining framework.
        
        Args:
            job_id: Job identifier
            request: Original job request parameters
        """
        n = request.get('n', 1)
        
        # Define the 3-stage sequence
        stage_sequence = {
            1: 'initial_hello',
            2: 'validation', 
            3: 'response'
        }
        
        # Initialize job stage configuration
        job_update = {
            'stages': 3,  # Total number of stages
            'current_stage_n': 1,  # Start at stage 1
            'current_stage': 'initial_hello',  # Current stage name
            'stage_sequence': json.dumps(stage_sequence),  # Stage number → stage name mapping
            'stage_data': json.dumps({  # Inter-stage data storage
                'n': n,  # Number of tasks for Stage 1 and Stage 3
                'base_message': request.get('message', 'Sequential Hello Test'),
                'stage1_results': [],  # Will store Stage 1 task results
                'stage2_validation': {},  # Will store Stage 2 validation result
                'stage3_task_mapping': {}  # Will store Stage 1 → Stage 3 task mapping
            }),
            'stage_history': json.dumps([])  # Will track stage completion history
        }
        
        # Update job record with stage configuration  
        self.job_repo.update_job_status(job_id, 'pending', job_update)
        
        self.logger.info(f"🎯 Initialized sequential job {job_id} with 3-stage configuration")
        self.logger.debug(f"Stage sequence: {stage_sequence}")
        self.logger.debug(f"Expected Stage 1 tasks: {n}, Expected Stage 3 tasks: {n}")
    
    def aggregate_results(self, task_results: List[Dict]) -> Dict:
        """
        Aggregate results from all 3 stages of sequential hello world job.
        
        This method is called only when ALL stages have completed, providing
        comprehensive statistics and validation of the sequential workflow.
        
        Args:
            task_results: List of task results from all stages
            
        Returns:
            Dict: Aggregated job result with sequential hello statistics
        """
        if not task_results:
            return {
                'status': 'no_results',
                'message': 'No sequential hello world task results to aggregate',
                'sequential_hello_statistics': {
                    'total_stages_completed': 0,
                    'stage1_hellos_requested': 0,
                    'stage1_hellos_successful': 0,
                    'stage2_validation_passed': False,
                    'stage3_responses_generated': 0,
                    'overall_success_rate': '0%'
                }
            }
        
        # Separate task results by stage
        stage1_tasks = [t for t in task_results if t.get('result', {}).get('stage') == 1]
        stage2_tasks = [t for t in task_results if t.get('result', {}).get('stage') == 2]
        stage3_tasks = [t for t in task_results if t.get('result', {}).get('stage') == 3]
        
        # Parse result data for each task
        for task in task_results:
            if isinstance(task.get('result'), str):
                try:
                    task['result'] = json.loads(task['result'])
                except:
                    pass
        
        # Analyze Stage 1 results
        stage1_successful = len([t for t in stage1_tasks if t.get('status') == 'completed'])
        stage1_total = len(stage1_tasks)
        
        # Analyze Stage 2 results
        stage2_validation_passed = False
        stage2_validation_result = {}
        if stage2_tasks:
            stage2_task = stage2_tasks[0]  # Should be only 1 validation task
            if stage2_task.get('status') == 'completed':
                stage2_result = stage2_task.get('result', {})
                stage2_validation_passed = stage2_result.get('status') == 'success'
                stage2_validation_result = stage2_result.get('validation_summary', {})
        
        # Analyze Stage 3 results
        stage3_successful = len([t for t in stage3_tasks if t.get('status') == 'completed'])
        stage3_total = len(stage3_tasks)
        
        # Calculate overall success rate
        total_expected_tasks = stage1_total + 1 + stage3_total  # Stage 1 + 1 validation + Stage 3
        total_successful_tasks = stage1_successful + (1 if stage2_validation_passed else 0) + stage3_successful
        overall_success_rate = (total_successful_tasks / total_expected_tasks * 100) if total_expected_tasks > 0 else 0
        
        # Build stage conversations showing Stage 1 → Stage 3 connections
        stage_conversations = []
        for stage3_task in stage3_tasks:
            if stage3_task.get('status') == 'completed':
                stage3_result = stage3_task.get('result', {})
                responds_to_task_id = stage3_result.get('responds_to_task_id')
                
                # Find corresponding Stage 1 task
                stage1_task = None
                for s1_task in stage1_tasks:
                    if s1_task.get('task_id') == responds_to_task_id:
                        stage1_task = s1_task
                        break
                
                if stage1_task:
                    stage1_result = stage1_task.get('result', {})
                    conversation = {
                        'stage1_task_id': responds_to_task_id,
                        'stage1_message': stage1_result.get('message', 'N/A'),
                        'stage3_task_id': stage3_task.get('task_id'),
                        'stage3_response': stage3_result.get('response_message', 'N/A'),
                        'conversation_complete': True
                    }
                    stage_conversations.append(conversation)
        
        # Get stage history from job record (if available)
        stage_history = []
        if task_results:
            # Try to get stage history from first task's job data (if job data is attached)
            # This would normally be retrieved from job record, but for aggregation we'll build it
            stage_history = [
                {
                    'stage_n': 1,
                    'stage': 'initial_hello',
                    'task_count': stage1_total,
                    'successful_tasks': stage1_successful,
                    'status': 'completed' if stage1_successful == stage1_total else 'partial',
                    'duration_seconds': self._calculate_stage_duration(stage1_tasks)
                },
                {
                    'stage_n': 2,
                    'stage': 'validation',
                    'task_count': 1,
                    'successful_tasks': 1 if stage2_validation_passed else 0,
                    'status': 'completed' if stage2_validation_passed else 'failed',
                    'duration_seconds': self._calculate_stage_duration(stage2_tasks)
                },
                {
                    'stage_n': 3,
                    'stage': 'response',
                    'task_count': stage3_total,
                    'successful_tasks': stage3_successful,
                    'status': 'completed' if stage3_successful == stage3_total else 'partial',
                    'duration_seconds': self._calculate_stage_duration(stage3_tasks)
                }
            ]
        
        # Determine overall job status
        if overall_success_rate == 100.0:
            overall_status = 'completed'
            overall_message = f"🎉 All 3 stages completed successfully! {stage1_total} Stage 1 hellos → 1 validation → {stage3_total} Stage 3 responses"
        elif overall_success_rate > 50.0:
            overall_status = 'completed_with_errors'
            overall_message = f"⚠️ Sequential job partially completed: {overall_success_rate:.1f}% success rate"
        else:
            overall_status = 'failed'
            overall_message = f"❌ Sequential job failed: {overall_success_rate:.1f}% success rate"
        
        # Build comprehensive result
        result = {
            'status': overall_status,
            'message': overall_message,
            'sequential_hello_statistics': {
                'total_stages_completed': 3,
                'stage1_hellos_requested': stage1_total,
                'stage1_hellos_successful': stage1_successful,
                'stage2_validation_passed': stage2_validation_passed,
                'stage2_validation_summary': stage2_validation_result,
                'stage3_responses_generated': stage3_successful,
                'stage3_responses_requested': stage3_total,
                'overall_success_rate': f"{overall_success_rate:.1f}%",
                'total_tasks_executed': total_expected_tasks,
                'total_tasks_successful': total_successful_tasks
            },
            'stage_conversations': stage_conversations[:10],  # First 10 conversations to avoid too much data
            'stage_history': stage_history,
            'task_summary_by_stage': {
                'stage1_initial_hello': {
                    'total_tasks': stage1_total,
                    'successful_tasks': stage1_successful,
                    'failed_tasks': stage1_total - stage1_successful
                },
                'stage2_validation': {
                    'total_tasks': len(stage2_tasks),
                    'successful_tasks': 1 if stage2_validation_passed else 0,
                    'failed_tasks': len(stage2_tasks) - (1 if stage2_validation_passed else 0)
                },
                'stage3_response': {
                    'total_tasks': stage3_total,
                    'successful_tasks': stage3_successful,
                    'failed_tasks': stage3_total - stage3_successful
                }
            },
            'sample_task_results': task_results[:5] if len(task_results) <= 5 else task_results[:5]  # Sample of task results
        }
        
        # Add truncation notice if there are many conversations
        if len(stage_conversations) > 10:
            result['stage_conversations'].append(f"... and {len(stage_conversations) - 10} more conversations")
        
        if len(task_results) > 5:
            result['additional_results_count'] = len(task_results) - 5
        
        return result
    
    def _calculate_stage_duration(self, stage_tasks: List[Dict]) -> float:
        """
        Calculate actual stage duration from task timing data.
        
        Args:
            stage_tasks: List of tasks for a specific stage
            
        Returns:
            float: Duration in seconds (actual measurement)
        """
        if not stage_tasks:
            return 0.0
        
        # Extract processing times from task results
        processing_times = []
        for task in stage_tasks:
            if task.get('status') == 'completed':
                result = task.get('result', {})
                if isinstance(result, dict):
                    processing_time = result.get('processing_time_seconds', 0.0)
                    if processing_time > 0:
                        processing_times.append(processing_time)
        
        # Return maximum processing time (longest task in the stage)
        return max(processing_times) if processing_times else 0.0