#!/bin/bash

# Geospatial Dashboard Deployment Script
# Deploys static website to Azure Storage Account

set -e  # Exit on any error

# Configuration
STORAGE_ACCOUNT="rmhazuregeo"
RESOURCE_GROUP="rmhazure_rg"  # Updated with correct resource group
FUNCTION_APP="rmhgeoapiqfn"
STATIC_WEBSITE_URL="https://rmhazuregeo.z13.web.core.windows.net"

echo "🌍 Deploying Geospatial Dashboard to Azure Storage Static Website"
echo "=================================================="

# Check if Azure CLI is installed
if ! command -v az &> /dev/null; then
    echo "❌ Azure CLI is not installed. Please install it first."
    echo "   https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
    exit 1
fi

# Check if logged in to Azure
echo "🔐 Checking Azure CLI authentication..."
if ! az account show &> /dev/null; then
    echo "❌ Not logged in to Azure. Please run 'az login' first."
    exit 1
fi

echo "✅ Azure CLI authenticated"

# Show current subscription
CURRENT_SUB=$(az account show --query name -o tsv)
echo "📍 Using subscription: $CURRENT_SUB"

# Enable static website hosting
echo "🌐 Enabling static website hosting..."
az storage blob service-properties update \
    --account-name $STORAGE_ACCOUNT \
    --static-website \
    --index-document index.html \
    --404-document 404.html \
    --auth-mode login

echo "✅ Static website hosting enabled"

# Verify required files exist
REQUIRED_FILES=("index.html" "dashboard.js" "404.html")
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "static-website/$file" ]; then
        echo "❌ Required file missing: static-website/$file"
        exit 1
    fi
done

echo "✅ All required files found"

# Upload files to storage account
echo "📤 Uploading files to Azure Storage..."
az storage blob upload-batch \
    --account-name $STORAGE_ACCOUNT \
    --destination '$web' \
    --source ./static-website \
    --overwrite \
    --auth-mode login

echo "✅ Files uploaded to storage account"

# Configure CORS on Function App
echo "🔗 Configuring CORS on Function App..."
# First, check existing CORS settings
EXISTING_CORS=$(az functionapp cors show \
    --name $FUNCTION_APP \
    --resource-group $RESOURCE_GROUP \
    --query allowedOrigins -o tsv 2>/dev/null || echo "")

if [[ $EXISTING_CORS == *"$STATIC_WEBSITE_URL"* ]]; then
    echo "✅ CORS already configured for $STATIC_WEBSITE_URL"
else
    az functionapp cors add \
        --name $FUNCTION_APP \
        --resource-group $RESOURCE_GROUP \
        --allowed-origins $STATIC_WEBSITE_URL
    echo "✅ CORS configured for $STATIC_WEBSITE_URL"
fi

# Also add localhost for development
if [[ $EXISTING_CORS != *"http://localhost:3000"* ]]; then
    az functionapp cors add \
        --name $FUNCTION_APP \
        --resource-group $RESOURCE_GROUP \
        --allowed-origins "http://localhost:3000" 2>/dev/null || true
    echo "✅ Added localhost:3000 for development"
fi

# Get the static website endpoint
echo "🔍 Getting static website endpoint..."
ENDPOINT=$(az storage account show \
    --name $STORAGE_ACCOUNT \
    --resource-group $RESOURCE_GROUP \
    --query "primaryEndpoints.web" -o tsv)

# Summary
echo ""
echo "🎉 Deployment Complete!"
echo "=================================================="
echo "Static Website URL: $ENDPOINT"
echo "Function App URL:   https://$FUNCTION_APP.azurewebsites.net"
echo ""
echo "Next steps:"
echo "1. Open the static website URL in your browser"
echo "2. The Function App URL should be pre-configured"
echo "3. Test the connection with 'Test Health Endpoint'"
echo "4. Try submitting a 'Hello World' test job"
echo ""
echo "Troubleshooting:"
echo "- If CORS errors occur, check browser console for details"
echo "- Verify Function App is running in Azure Portal"
echo "- Check that anonymous access is enabled on Function App"
echo ""

# Optional: Open in browser (macOS/Linux)
if command -v open &> /dev/null; then
    echo "🌐 Opening website in browser..."
    open "$ENDPOINT"
elif command -v xdg-open &> /dev/null; then
    echo "🌐 Opening website in browser..."
    xdg-open "$ENDPOINT"
else
    echo "💡 Open this URL in your browser: $ENDPOINT"
fi