#!/bin/bash

# Geospatial Dashboard Deployment Script
# Deploys static website to Azure Storage Account

set -e  # Exit on any error

# Configuration
STORAGE_ACCOUNT="rmhazuregeo"
RESOURCE_GROUP="your-resource-group"  # Update this
FUNCTION_APP="rmhgeoapiqfn-h3dza4gyffbsbre7"
STATIC_WEBSITE_URL="https://rmhazuregeo.z13.web.core.windows.net"

echo "🌍 Deploying Geospatial Dashboard to Azure Storage Static Website"
echo "=================================================="

# Check if Azure CLI is installed
if ! command -v az &> /dev/null; then
    echo "❌ Azure CLI is not installed. Please install it first."
    echo "   https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
    exit 1
fi

# Check if logged in to Azure
echo "🔐 Checking Azure CLI authentication..."
if ! az account show &> /dev/null; then
    echo "❌ Not logged in to Azure. Please run 'az login' first."
    exit 1
fi

echo "✅ Azure CLI authenticated"

# Verify storage account exists
echo "🏪 Verifying storage account exists..."
if ! az storage account show --name $STORAGE_ACCOUNT --resource-group $RESOURCE_GROUP &> /dev/null; then
    echo "❌ Storage account '$STORAGE_ACCOUNT' not found in resource group '$RESOURCE_GROUP'"
    echo "   Please update the STORAGE_ACCOUNT and RESOURCE_GROUP variables in this script"
    exit 1
fi

echo "✅ Storage account found: $STORAGE_ACCOUNT"

# Enable static website hosting
echo "🌐 Enabling static website hosting..."
az storage blob service-properties update \
    --account-name $STORAGE_ACCOUNT \
    --static-website \
    --index-document index.html \
    --404-document 404.html

echo "✅ Static website hosting enabled"

# Create local directory structure if it doesn't exist
if [ ! -d "static-website" ]; then
    echo "📁 Creating static-website directory..."
    mkdir -p static-website
    echo "⚠️  Please add your HTML and JavaScript files to the 'static-website' directory"
    echo "   Required files:"
    echo "   - index.html"
    echo "   - dashboard.js"
    echo "   - 404.html (optional)"
    exit 1
fi

# Verify required files exist
REQUIRED_FILES=("index.html" "dashboard.js")
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "static-website/$file" ]; then
        echo "❌ Required file missing: static-website/$file"
        exit 1
    fi
done

echo "✅ Required files found"

# Upload files to storage account
echo "📤 Uploading files to Azure Storage..."
az storage blob upload-batch \
    --account-name $STORAGE_ACCOUNT \
    --destination '$web' \
    --source ./static-website \
    --overwrite \
    --auth-mode login

echo "✅ Files uploaded to storage account"

# Configure CORS on Function App
echo "🔗 Configuring CORS on Function App..."
az functionapp cors add \
    --name $FUNCTION_APP \
    --resource-group $RESOURCE_GROUP \
    --allowed-origins $STATIC_WEBSITE_URL

echo "✅ CORS configured"

# Test the deployment
echo "🧪 Testing deployment..."
HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" $STATIC_WEBSITE_URL)
if [ "$HTTP_STATUS" = "200" ]; then
    echo "✅ Static website is accessible"
else
    echo "⚠️  Website returned HTTP $HTTP_STATUS (may take a few minutes to propagate)"
fi

# Summary
echo ""
echo "🎉 Deployment Complete!"
echo "=================================================="
echo "Static Website URL: $STATIC_WEBSITE_URL"
echo "Function App URL:   https://$FUNCTION_APP.azurewebsites.net"
echo ""
echo "Next steps:"
echo "1. Open the static website URL in your browser"
echo "2. Test the connection to your Function App"
echo "3. Try submitting a test job"
echo ""
echo "Troubleshooting:"
echo "- If CORS errors occur, verify the Function App CORS settings"
echo "- If functions don't respond, check Function App status in Azure Portal"
echo "- View browser developer console for detailed error messages"
echo ""

# Optional: Open in browser (macOS/Linux with xdg-open or open command)
if command -v open &> /dev/null; then
    echo "🌐 Opening website in browser..."
    open $STATIC_WEBSITE_URL
elif command -v xdg-open &> /dev/null; then
    echo "🌐 Opening website in browser..."
    xdg-open $STATIC_WEBSITE_URL
else
    echo "💡 Manually open this URL in your browser: $STATIC_WEBSITE_URL"
fi